// Basic Express Server Setup
const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000; // Use environment variable or default to 3000

// Middleware (Example: for parsing JSON request bodies)
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Placeholder for API routes
// const authRoutes = require('./routes/auth');
// app.use('/api/auth', authRoutes);

// Basic route for testing
app.get('/api/test', (req, res) => {
    res.json({ message: 'Backend is running!' });
});

// Serve static frontend files (if needed, adjust path)
// app.use(express.static(path.join(__dirname, '../src'))); 

// Start the server
app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
});
