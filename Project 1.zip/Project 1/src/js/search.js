// Placeholder data mimicking the structure we expect from the backend
const sampleApiResponse = [
    {
        id: 1,
        name: "Samsung Galaxy S24 Ultra",
        image: "https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcRCjyekLTGxFsl4qRLxSG1Z-mqNJWIzPgRkGKmbrbqdmOmpH6D2Rh8z-rRBfO2o1wfXa-uRmj_LDp0YsbFNCB6kCLfvZ3ts",
        category: "electronics",
        description: "High-end smartphone with advanced camera.",
        prices: [
            { platform: "Amazon", price: 1199.99, url: "#amazon-s23", rating: 4.8, reviews: 5213 },
            { platform: "Flipkart", price: 1189.99, url: "#flipkart-s23", rating: 4.7, reviews: 4890 },
            { platform: "Best Buy", price: 1219.99, url: "#bestbuy-s23", rating: 4.8, reviews: 5100 }
        ]
    },
    {
        id: 2,
        name: "MacBook Air M2",
        image: "https://store.storeimages.cdn-apple.com/1/as-images.apple.com/is/mba13-silver-cto-hero-202503?wid=840&hei=498&fmt=jpeg&qlt=90&.v=U0Z6SXlYc1BFM1JiK2VsbitpZmJQbTlvelV1clpMQ1I3STRPWXROdW1jM3c5YVIwb1U2bDJuTk1wdkVlT3RmUk14MXJScFRZN3Y5OWZsRXVrN1k4cGRRc1UweFFQYjRpK3pPQllDSFNnc0U",
        category: "electronics",
        description: "Apple's lightweight laptop with M2 chip.",
        prices: [
            { platform: "Amazon", price: 1299.00, url: "#amazon-mba", rating: 4.9, reviews: 3456 },
            { platform: "Best Buy", price: 1319.00, url: "#bestbuy-mba", rating: 4.9, reviews: 3300 }
        ]
    },
    {
        id: 3,
        name: "Sony WH-1000XM5",
        image: "https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcQ0R9BC93mX2BHmhNoJjGi-IJ4DXM6-uIE9he2GD2saKZ_ogUMAqPksTtnT-oXSMtTsKplSmYuh6dL0q0n83fKOybZx5eg4bw",
        category: "electronics",
        description: "Industry-leading noise-canceling headphones.",
        prices: [
            { platform: "Amazon", price: 399.99, url: "#amazon-xm5", rating: 4.7, reviews: 2123 },
            { platform: "Flipkart", price: 389.99, url: "#flipkart-xm5", rating: 4.6, reviews: 1980 },
        ]
    },
    {
        id: 4,
        name: "Nike Air Max 270 ",
        image: "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcQSuVPbLK3ck3C5zf0DWrLps_Ao3-2GGNxsyvpHvrrqJ1shLf3zV6rbYBc8ZnlwHEzuQ_fkIWnDyuvQoKnGlRLLkr57AdQKY-t_oM3ltshOgwSuBDQydT1q1w",
        category: "fashion",
        description: "Comfortable lifestyle sneakers.",
        prices: [
            { platform: "Amazon", price: 149.99, url: "#amazon-nike", rating: 4.6, reviews: 1530 },
            { platform: "Flipkart", price: 139.99, url: "#flipkart-nike", rating: 4.5, reviews: 1400 }
        ]
    },
    {
        id: 5,
        name: "Levi's 501 Jeans",
        image: "https://assets.ajio.com/medias/sys_master/root/hd3/hf3/9262962343966/-473Wx593H-460027749-blue-MODEL6.jpg",
        category: "fashion",
        description: "Classic straight fit denim jeans.",
        prices: [
            { platform: "Amazon", price: 89.99, url: "#amazon-levis", rating: 4.4, reviews: 2800 },
            { platform: "Best Buy", price: 95.99, url: "#bestbuy-levis", rating: 4.5, reviews: 2650 }
        ]
    },
    {
        id: 6,
        name: "Philips Hue Smart Bulb",
        image: "https://cdn.shopify.com/s/files/1/0648/5478/6148/files/Image1.jpg?v=1722580287",
        category: "home",
        description: "Color ambiance smart light bulb.",
        prices: [
            { platform: "Amazon", price: 49.99, url: "#amazon-hue", rating: 4.7, reviews: 9800 },
            { platform: "Best Buy", price: 52.99, url: "#bestbuy-hue", rating: 4.7, reviews: 9500 }
        ]
    },
    {
        id: 7,
        name: "Instant Pot Duo",
        image: "https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcQCXuNp469RBPjnO1Mu7mP2ceIL0zPR5ZNS6f91m2eujg-Tv5ssT3Laslj3oGMF5zbPZsMnQjqJQJvkYkJgZTUg_tiWnEAyRzWlXhNsuWbc4bMRU0snm1uNDw",
        category: "home",
        description: "7-in-1 electric pressure cooker.",
        prices: [
            { platform: "Amazon", price: 89.99, url: "#amazon-ipot", rating: 4.8, reviews: 15000 },
            { platform: "Flipkart", price: 85.99, url: "#flipkart-ipot", rating: 4.7, reviews: 14200 }
        ]
    },
    {
        id: 8,
        name: "Atomic Habits",
        image: "https://m.media-amazon.com/images/I/61Bhf8CdaML._SY466_.jpg",
        category: "books",
        description: "An Easy & Proven Way to Build Good Habits & Break Bad Ones.",
        prices: [
            { platform: "Amazon", price: 14.99, url: "#amazon-ah", rating: 4.9, reviews: 55000 },
            { platform: "Flipkart", price: 13.99, url: "#flipkart-ah", rating: 4.8, reviews: 52100 }
        ]
    },
    {
        id: 9,
        name: "Fitbit Charge 5",
        image: "https://m.media-amazon.com/images/I/61Llpu4OGYL._SX679_PIbundle-4,TopRight,0,0_AA679SH20_.jpg",
        category: "sports",
        description: "Advanced fitness & health tracker.",
        prices: [
            { platform: "Amazon", price: 149.95, url: "#amazon-fitbit", rating: 4.4, reviews: 12000 },
            { platform: "Best Buy", price: 149.99, url: "#bestbuy-fitbit", rating: 4.4, reviews: 11500 }
        ]
    }
];

document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('search-input');
    const searchButton = document.querySelector('.search-btn');
    const resultsGrid = document.getElementById('results-grid');
    const categoryButtons = document.querySelectorAll('.category-btn');
    const platformFilter = document.getElementById('platform-filter');
    const priceFilter = document.getElementById('price-filter');

    // --- Event Listeners ---
    if (searchButton) {
        searchButton.addEventListener('click', handleSearch);
    }
    if (searchInput) {
        searchInput.addEventListener('keypress', (event) => {
            if (event.key === 'Enter') {
                handleSearch();
            }
        });
    }

    categoryButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Deactivate other buttons
            categoryButtons.forEach(btn => btn.classList.remove('active'));
            // Activate clicked button
            button.classList.add('active');
            // Trigger filtering based on the selected category
            filterAndDisplayResults();
        });
    });

    if (platformFilter) platformFilter.addEventListener('change', filterAndDisplayResults);
    if (priceFilter) priceFilter.addEventListener('change', filterAndDisplayResults);


    // --- Functions ---
    function handleSearch() {
        const searchTerm = searchInput ? searchInput.value.trim() : '';
        console.log(`Searching for: ${searchTerm}`);
        fetchAndDisplayResults(searchTerm);
    }

    async function fetchAndDisplayResults(searchTerm = '') {
        if (!resultsGrid) {
            console.error("Results grid not found!");
            return;
        }
        resultsGrid.innerHTML = '<p class="loading-message">Loading results...</p>'; // Show loading indicator

        try {
            // ** Placeholder: Replace with actual API call when backend is ready **
            // const response = await fetch(`/api/search?q=${encodeURIComponent(searchTerm)}`);
            // if (!response.ok) {
            //     throw new Error(`HTTP error! status: ${response.status}`);
            // }
            // const results = await response.json();

            // Using sample data for now
            await new Promise(resolve => setTimeout(resolve, 500)); // Simulate network delay
            const results = filterResults(sampleApiResponse, searchTerm); // Filter mock data

            displayResults(results);

        } catch (error) {
            console.error("Error fetching search results:", error);
            resultsGrid.innerHTML = `<p class="error-message">Could not load results. ${error.message}</p>`;
        }
    }

    function filterResults(products, searchTerm) {
        const termLower = searchTerm.toLowerCase();
        if (!termLower) return products; // Return all if search term is empty

        return products.filter(product =>
            product.name.toLowerCase().includes(termLower) ||
            product.description.toLowerCase().includes(termLower) ||
            product.category.toLowerCase().includes(termLower)
        );
    }

    function filterAndDisplayResults() {
        const activeCategory = document.querySelector('.category-btn.active')?.dataset.category || 'all';
        const selectedPlatform = platformFilter ? platformFilter.value : '';
        const selectedPriceRange = priceFilter ? priceFilter.value : '';

        let filteredProducts = sampleApiResponse; // Start with all products

        // 1. Filter by Category
        if (activeCategory !== 'all') {
            filteredProducts = filteredProducts.filter(p => p.category === activeCategory);
        }

        // 2. Filter by Platform (check if product has *any* price listing for the platform)
        if (selectedPlatform) {
             filteredProducts = filteredProducts.filter(p => p.prices.some(priceInfo => priceInfo.platform.toLowerCase() === selectedPlatform.toLowerCase()));
        }

        // 3. Filter by Price Range
        if (selectedPriceRange) {
            const [minPrice, maxPrice] = parsePriceRange(selectedPriceRange);
            filteredProducts = filteredProducts.filter(p => {
                // Check if *any* price on *any* platform falls within the range
                return p.prices.some(priceInfo => {
                    const price = priceInfo.price;
                    const meetsMin = minPrice === null || price >= minPrice;
                    const meetsMax = maxPrice === null || price <= maxPrice;
                    return meetsMin && meetsMax;
                });
            });
        }

        // Optional: Re-apply search term if needed (or assume filters apply to current search results)
        const currentSearchTerm = searchInput ? searchInput.value.trim() : '';
        if (currentSearchTerm) {
             filteredProducts = filterResults(filteredProducts, currentSearchTerm);
        }


        displayResults(filteredProducts);
    }

    function parsePriceRange(rangeString) {
        if (!rangeString) return [null, null];
        if (rangeString.includes('+')) {
            return [parseFloat(rangeString.replace('+', '')), null];
        }
        const parts = rangeString.split('-');
        if (parts.length === 2) {
            return [parseFloat(parts[0]), parseFloat(parts[1])];
        }
        return [null, null]; // Invalid format
    }


    function displayResults(products) {
        if (!resultsGrid) return;
        resultsGrid.innerHTML = ''; // Clear previous results or loading message

        if (products.length === 0) {
            resultsGrid.innerHTML = '<p class="no-results-message">No products found matching your criteria.</p>';
            return;
        }

        products.forEach(product => {
            const bestPriceInfo = findBestPrice(product.prices);
            const productCard = document.createElement('div');
            productCard.className = 'result-card'; // Use a different class to avoid style conflicts
            // Check for a valid image, otherwise use local placeholder
            const imageUrl = product.image && product.image.trim() !== '' ? product.image : 'images/placeholder-category.png';
            
            productCard.innerHTML = `
                <div class="result-image">
                    <img src="${imageUrl}" alt="${product.name}">
                </div>
                <div class="result-info">
                    <h3>${product.name}</h3>
                    <p class="description">${product.description || 'No description available.'}</p>
                    <div class="price-comparison">
                        <h4>Prices:</h4>
                        <ul>
                            ${product.prices.map(p => `<li>${p.platform}: ₹${Math.round(p.price * 83).toLocaleString('en-IN')}</li>`).join('')}
                        </ul>
                    </div>
                    ${bestPriceInfo ? `
                    <div class="best-offer">
                        <strong>Best Price:</strong> ₹${Math.round(bestPriceInfo.price * 83).toLocaleString('en-IN')} on ${bestPriceInfo.platform}
                        <a href="${bestPriceInfo.url}" target="_blank" class="btn-view-deal">View Deal</a>
                    </div>
                    ` : '<p>No pricing information available.</p>'}
                </div>
            `;
            // Optional: Add click listener to card for details page
            productCard.addEventListener('click', () => {
                 window.location.href = `product-details.html?id=${product.id}`; 
                 console.log(`Navigate to details for product ID: ${product.id}`);
            });

            resultsGrid.appendChild(productCard);
        });
    }

    function findBestPrice(prices) {
        if (!prices || prices.length === 0) {
            return null;
        }
        return prices.reduce((best, current) => {
            if (!best || current.price < best.price) {
                return current;
            }
            return best;
        }, null);
    }

    // Initial load (optional - you might want to wait for a search)
    // displayResults(sampleApiResponse); // Display all mock products initially
     filterAndDisplayResults(); // Display based on default filters

});