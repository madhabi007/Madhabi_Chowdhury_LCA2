document.addEventListener('DOMContentLoaded', () => {
    const dealsGrid = document.querySelector('.deals-grid');
    const couponsGrid = document.querySelector('.coupons-grid');

    // Fetch offer data
    fetch('src/data/offers-data.json')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (dealsGrid) {
                populateDeals(data.deals);
            }
            if (couponsGrid) {
                populateCoupons(data.coupons);
            }
        })
        .catch(error => {
            console.error('Error fetching or parsing offers data:', error);
            if (dealsGrid) dealsGrid.innerHTML = '<p class="error-message">Could not load deals.</p>';
            if (couponsGrid) couponsGrid.innerHTML = '<p class="error-message">Could not load coupons.</p>';
        });

    function populateDeals(deals) {
        dealsGrid.innerHTML = ''; // Clear existing static content or error message
        if (!deals || deals.length === 0) {
            dealsGrid.innerHTML = '<p>No deals available right now.</p>';
            return;
        }
        deals.forEach(deal => {
            const dealCard = document.createElement('div');
            dealCard.className = 'deal-card';
            dealCard.innerHTML = `
                <div class="deal-badge">${deal.badge}</div>
                <img src="${deal.image}" alt="${deal.title}">
                <div class="deal-content">
                    <h3>${deal.title}</h3>
                    <p>${deal.description}</p>
                    <div class="deal-meta">
                        <span class="expiry">Expires: ${deal.expiry}</span>
                        <button class="copy-code" data-code="${deal.code || deal.badge}">Copy Code</button>
                    </div>
                </div>
            `;
            dealsGrid.appendChild(dealCard);
        });
    }

    function populateCoupons(coupons) {
        couponsGrid.innerHTML = ''; // Clear existing static content or error message
        if (!coupons || coupons.length === 0) {
            couponsGrid.innerHTML = '<p>No coupons available right now.</p>';
            return;
        }
        coupons.forEach(coupon => {
            const couponCard = document.createElement('div');
            couponCard.className = 'coupon-card';
            couponCard.innerHTML = `
                <div class="coupon-code">${coupon.code}</div>
                <div class="coupon-content">
                    <h3>${coupon.title}</h3>
                    <p>${coupon.description}</p>
                    <div class="coupon-meta">
                        <span>${coupon.validity}</span>
                        <button class="copy-code" data-code="${coupon.code}">Copy Code</button>
                    </div>
                </div>
            `;
            couponsGrid.appendChild(couponCard);
        });
    }

    // Event Delegation for Copy Buttons
    document.body.addEventListener('click', handleCopyCode);

    function handleCopyCode(e) {
        // Check if the clicked element is a copy button
        if (!e.target.classList.contains('copy-code')) {
            return;
        }

        const button = e.target;
        const code = button.dataset.code; // Get code from data attribute
        
        if (!code) {
            console.error('No code found for button:', button);
            return;
        }

        // Copy code to clipboard
        navigator.clipboard.writeText(code)
            .then(() => {
                // Show success message
                const originalText = button.textContent;
                button.textContent = 'Copied!';
                button.disabled = true;
                button.style.backgroundColor = '#28a745'; // Success green
                button.style.cursor = 'default';
                
                // Reset button after 2 seconds
                setTimeout(() => {
                    button.textContent = originalText;
                    button.disabled = false;
                    button.style.backgroundColor = '';
                    button.style.cursor = 'pointer';
                }, 2000);
            })
            .catch(err => {
                console.error('Failed to copy code:', err);
                button.textContent = 'Failed!';
                button.disabled = true;
                button.style.backgroundColor = '#dc3545'; // Error red
                button.style.cursor = 'default';

                // Reset button after 2 seconds
                setTimeout(() => {
                    button.textContent = originalText;
                    button.disabled = false;
                    button.style.backgroundColor = '';
                    button.style.cursor = 'pointer';
                }, 2000);
            });
    }

    // --- Dark Mode Toggle Functionality --- (Keep existing code)
    const darkModeToggle = document.createElement('button');
    darkModeToggle.className = 'dark-mode-toggle';
    darkModeToggle.innerHTML = '<i class="fas fa-moon"></i>'; 
    // Check if dark mode is preferred or previously set
    if (localStorage.getItem('darkMode') === 'enabled' || 
        (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches && localStorage.getItem('darkMode') !== 'disabled')) {
        document.body.classList.add('dark-mode');
        darkModeToggle.innerHTML = '<i class="fas fa-sun"></i>';
    }
    document.body.appendChild(darkModeToggle);

    darkModeToggle.addEventListener('click', () => {
        document.body.classList.toggle('dark-mode');
        const isDarkMode = document.body.classList.contains('dark-mode');
        const icon = darkModeToggle.querySelector('i');
        if (isDarkMode) {
            icon.classList.remove('fa-moon');
            icon.classList.add('fa-sun');
            localStorage.setItem('darkMode', 'enabled');
        } else {
            icon.classList.remove('fa-sun');
            icon.classList.add('fa-moon');
            localStorage.setItem('darkMode', 'disabled');
        }
    });
});