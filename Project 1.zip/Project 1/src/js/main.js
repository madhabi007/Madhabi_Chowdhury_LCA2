// Sample product data (in a real application, this would come from an API)
const sampleProducts = [
    {
        id: 1,
        name: "Samsung Galaxy S23 Ultra",
        price: 1199.99,
        description: "The ultimate smartphone experience with a pro-grade camera.",
        image: "images/placeholder-category.png",
        category: "Electronics",
        rating: 4.8,
        reviews: 150,
        store: "Samsung",
        url: "product-details.html?id=1"
    },
    {
        id: 2,
        name: "Nike AirMax 270",
        price: 150.00,
        description: "Iconic Air Max comfort with a modern design.",
        image: "images/placeholder-category.png",
        category: "Shoes",
        rating: 4.5,
        reviews: 300,
        store: "Nike",
        url: "product-details.html?id=2"
    }
];

// Loading Overlay Handler
const loadingOverlay = document.querySelector('.loading-overlay');

function setLoadingOverlay(active) {
    if (!loadingOverlay) return;
    
    if (active) {
        loadingOverlay.classList.add('active');
    } else {
        loadingOverlay.classList.remove('active');
    }
}

// Initialize loading overlay
setLoadingOverlay(true);

// Wait for DOM to be fully loaded
window.addEventListener('DOMContentLoaded', () => {
    // Check user state immediately
    checkUserState();
    
    // Hide loading overlay after DOM is loaded
    setLoadingOverlay(false);
});

// Wait for page load to set up event listeners
window.addEventListener('load', () => {
    // DOM Elements
    const searchInput = document.getElementById('search-input');
    const searchBtn = document.querySelector('.search-btn');
    const profilePopup = document.getElementById('profilePopup');
    const userInitials = document.querySelector('.user-initials');
    const profileContent = document.querySelector('.profile-content');

    // Event Listeners
    if (searchBtn) {
        searchBtn.addEventListener('click', handleSearch);
    }
    if (searchInput) {
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                handleSearch();
            }
        });
    }

    // Profile popup event listeners
    if (userInitials) {
        userInitials.addEventListener('click', (e) => {
            e.stopPropagation();
            toggleProfilePopup();
        });
    }

    // Close popup when clicking outside
    if (profilePopup) {
        profilePopup.addEventListener('click', (e) => {
            if (e.target === profilePopup) {
                closeProfilePopup();
            }
        });
    }

    // Prevent click events from bubbling up when clicking inside popup
    if (profileContent) {
        profileContent.addEventListener('click', (e) => {
            e.stopPropagation();
        });
    }
});

// Functions
function checkUserState() {
    const user = JSON.parse(localStorage.getItem('user'));
    
    // Hide both elements first
    if (profileSection) {
        profileSection.classList.remove('active', 'show');
    }
    if (loginLink) {
        loginLink.classList.remove('active', 'show');
    }

    // Show appropriate element
    if (user) {
        // Show profile section
        if (profileSection) {
            profileSection.classList.add('active');
        }
        showProfile(user);
    } else {
        // Show login link
        if (loginLink) {
            loginLink.classList.add('show');
        }
    }
}

function showProfile(user) {
    // Update profile data
    const userName = document.getElementById('userName');
    const userEmail = document.getElementById('userEmail');
    const ordersCount = document.getElementById('ordersCount');
    const points = document.getElementById('points');
    const userInitials = document.querySelector('.user-initials span');

    // Check if elements exist before updating
    if (userInitials) {
        // Use stored initials if available
        userInitials.textContent = user.initials || user.name[0].toUpperCase();
    }
    if (userName) userName.textContent = user.name || 'User';
    if (userEmail) userEmail.textContent = user.email || 'user@example.com';
    if (ordersCount) ordersCount.textContent = user.orders || 0;
    if (points) points.textContent = user.points || 0;
    
    // Update profile popup initials
    const profileInitials = document.getElementById('profileInitials');
    if (profileInitials) {
        profileInitials.textContent = user.initials || user.name[0].toUpperCase();
    }
    
    // Show profile section and hide login link
    if (profileSection) {
        profileSection.style.display = 'flex';
    }
    if (loginLink) {
        loginLink.style.display = 'none';
    }
}

function toggleProfilePopup() {
    if (profilePopup) {
        profilePopup.classList.add('show');
        // Add click outside listener
        document.addEventListener('click', handleOutsideClick);
    }
}

function closeProfilePopup() {
    if (profilePopup) {
        profilePopup.classList.remove('show');
        // Remove click outside listener
        document.removeEventListener('click', handleOutsideClick);
    }
}

function handleOutsideClick(e) {
    if (profilePopup && !profilePopup.contains(e.target) && !e.target.closest('.user-initials')) {
        closeProfilePopup();
    }
}

function closeProfilePopup() {
    profilePopup.classList.remove('show');
}

function logout() {
    // Clear user data
    localStorage.removeItem('user');
    
    // Update UI
    checkUserState();
    
    // Redirect to login page after a short delay to ensure UI updates
    setTimeout(() => {
        window.location.href = 'login.html';
    }, 300);
}

// Functions
function handleSearch() {
    const searchTerm = searchInput.value.trim();
    if (searchTerm) {
        // In a real application, this would make an API call
        const results = searchProducts(searchTerm);
        if (results.length > 0) {
            // Redirect to search results page with the search term
            window.location.href = `search.html?q=${encodeURIComponent(searchTerm)}`;
        } else {
            showNoResultsMessage();
        }
    }
}

function searchProducts(term) {
    // Efficient search implementation using toLowerCase() once
    const searchTerm = term.toLowerCase();
    return sampleProducts.filter(product => 
        product.name.toLowerCase().includes(searchTerm)
    );
}

function showNoResultsMessage() {
    // Create and show a notification
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = 'No results found. Please try a different search term.';
    document.body.appendChild(notification);

    // Remove notification after 1 second
    setTimeout(() => {
        notification.remove();
    }, 1000);
}

// Add smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});

// Add loading skeleton for search results
function createLoadingSkeleton() {
    const skeleton = document.createElement('div');
    skeleton.className = 'skeleton';
    skeleton.innerHTML = `
        <div class="skeleton-image"></div>
        <div class="skeleton-text"></div>
        <div class="skeleton-text"></div>
    `;
    return skeleton;
}

// Add dark mode toggle functionality
const darkModeToggle = document.createElement('button');
darkModeToggle.className = 'dark-mode-toggle';
darkModeToggle.innerHTML = '<i class="fas fa-moon"></i>';
document.body.appendChild(darkModeToggle);

darkModeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    const icon = darkModeToggle.querySelector('i');
    icon.classList.toggle('fa-moon');
    icon.classList.toggle('fa-sun');
});

// Add CSS for dark mode
const style = document.createElement('style');
style.textContent = `
    .dark-mode {
        --background-color: #1a1a1a;
        --text-color: #fff;
        --card-background: #2d2d2d;
    }
    
    .notification {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background-color: var(--secondary-color);
        color: white;
        padding: 1rem;
        border-radius: 5px;
        animation: slideIn 0.3s ease-out;
    }
    
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    .skeleton {
        background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
        background-size: 200% 100%;
        animation: loading 1.5s infinite;
    }
    
    @keyframes loading {
        0% {
            background-position: 200% 0;
        }
        100% {
            background-position: -200% 0;
        }
    }
    
    .dark-mode-toggle {
        position: fixed;
        bottom: 20px;
        left: 20px;
        background-color: var(--secondary-color);
        color: white;
        border: none;
        border-radius: 50%;
        width: 50px;
        height: 50px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: var(--shadow);
        transition: var(--transition);
    }
    
    .dark-mode-toggle:hover {
        transform: scale(1.1);
    }
`;

document.head.appendChild(style);

// Add other general scripts or event listeners needed across the site below

// Example: Basic search functionality (if needed globally, otherwise keep in specific page scripts)
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('search-input');
    const searchButton = document.querySelector('.search-btn');

    // Function to perform search (redirects to search page)
    const performSearch = () => {
        const query = searchInput ? searchInput.value.trim() : '';
        if (query) {
            // Redirect to search.html with the query
            window.location.href = `search.html?query=${encodeURIComponent(query)}`;
        } else {
            // Optionally handle empty search - maybe focus input or show message
            if (searchInput) searchInput.focus();
        }
    };

    // Add event listener for button click
    if (searchButton) {
        searchButton.addEventListener('click', performSearch);
    }

    // Add event listener for Enter key in search input
    if (searchInput) {
        searchInput.addEventListener('keypress', (event) => {
            if (event.key === 'Enter') {
                event.preventDefault(); // Prevent default form submission if it's in a form
                performSearch();
            }
        });
    }
});