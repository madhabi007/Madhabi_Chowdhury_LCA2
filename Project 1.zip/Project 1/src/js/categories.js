// Sample data for product categories
const sampleCategories = [
    {
        name: "Electronics",
        slug: "electronics",
        icon: "fa-mobile-alt",
        image: "https://m.media-amazon.com/images/G/31/intel/mayart/Intel-1400x800._SX1242_QL85_.jpg",
        description: "Latest gadgets, smartphones, laptops, and more."
    },
    {
        name: "Fashion",
        slug: "fashion",
        icon: "fa-tshirt",
        image: "https://i.pinimg.com/736x/01/2b/06/012b06460ce60608d5e1677166b5e981.jpg",
        description: "Trendy clothing, accessories, and footwear."
    },
    {
        name: "Home & Garden",
        slug: "home-garden",
        icon: "fa-couch",
        image: "https://tinuiti.com/wp-content/uploads/2023/12/stoneandbeam.png.png",
        description: "Furniture, decor, kitchenware, and garden tools."
    },
    {
        name: "Books",
        slug: "books",
        icon: "fa-book-open",
        image: "https://static.vecteezy.com/system/resources/previews/043/192/089/non_2x/world-book-day-web-banner-open-book-with-floral-pattern-festive-invitation-background-for-books-lovers-hand-drawn-lettering-horizontal-backdrop-postcard-poster-template-flat-illustration-vector.jpg",
        description: "Bestsellers, fiction, non-fiction, and educational books."
    },
    {
        name: "Sports & Outdoors",
        slug: "sports-outdoors",
        icon: "fa-futbol",
        image: "https://images.jdmagicbox.com/quickquotes/listicle/listicle_1708569092834_yiyev_847x400.jpg",
        description: "Equipment for various sports and outdoor activities."
    },
    {
        name: "Beauty & Health",
        slug: "beauty-health",
        icon: "fa-heartbeat",
        image: "https://cdn.logojoy.com/wp-content/uploads/20191023114758/AdobeStock_224061283-min-1024x683.jpeg",
        description: "Skincare, makeup, supplements, and wellness products."
    },
    {
        name: "Toys & Games",
        slug: "toys-games",
        icon: "fa-puzzle-piece",
        image: "https://media.licdn.com/dms/image/v2/C4E1BAQFPJ8giRpTdoA/company-background_1536_768/company-background_1536_768/0/1584132649128?e=2147483647&v=beta&t=RMP0Kcmnn2zEFvjNn4DJaaaXipTJH3wTiAcsYF-l1PU",
        description: "Fun and educational toys and games for all ages."
    },
    {
        name: "Automotive",
        slug: "automotive",
        icon: "fa-car",
        image: "https://mediapool.bmwgroup.com/cache/P9/201302/P90114810/P90114810-design-impulse-campaign-2013-february-2013-600px.jpg",
        description: "Parts, accessories, and tools for vehicles."
    }
];

document.addEventListener('DOMContentLoaded', () => {
    const categoryGrid = document.querySelector('.category-grid');

    if (categoryGrid) {
        // Clear any static placeholders (though we'll remove them from HTML too)
        categoryGrid.innerHTML = ''; 

        sampleCategories.forEach(category => {
            const card = document.createElement('div');
            card.classList.add('card', 'category-card');

            card.innerHTML = `
                <div class="category-image-wrapper">
                    <img class="category-image" src="${category.image}" alt="${category.name} image" loading="lazy">
                </div>
                <div class="category-icon">
                    <i class="fas ${category.icon}"></i>
                </div>
                <h3>${category.name}</h3>
                <p>${category.description}</p>
                <a href="search.html?category=${category.slug}" class="btn btn-secondary">View Products</a>
            `;

            categoryGrid.appendChild(card);
        });
    } else {
        console.error('Category grid container not found!');
    }
});
