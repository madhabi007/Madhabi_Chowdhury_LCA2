document.addEventListener('DOMContentLoaded', () => {
    // Ensure sampleApiResponse is loaded (assuming search.js is loaded first)
    if (typeof sampleApiResponse === 'undefined') {
        console.error('Featured products data (sampleApiResponse) not found. Make sure search.js is loaded before home.js');
        return;
    }

    const featuredProductsGrid = document.querySelector('.featured-products .product-grid');

    if (!featuredProductsGrid) {
        console.error('Featured products grid container not found.');
        return;
    }

    // --- Define which products to feature (e.g., first 4) ---
    const productsToFeature = sampleApiResponse.slice(0, 4); 

    // --- Clear existing static placeholders --- 
    featuredProductsGrid.innerHTML = ''; 

    // --- Generate and append product cards --- 
    productsToFeature.forEach(product => {
        const card = document.createElement('div');
        card.classList.add('card');

        // Use a placeholder if the real image is missing or empty
        const imageUrl = product.image && product.image.trim() !== '' ? product.image : 'samsung'; // Use local placeholder
        
        // Find the best price (or lowest price) to display optionally
        let bestPriceInfo = '';
        if (product.prices && product.prices.length > 0) {
            const lowestPriceUSD = product.prices.reduce((min, p) => p.price < min ? p.price : min, product.prices[0].price);
            const lowestPriceINR = Math.round(lowestPriceUSD * 83);
            bestPriceInfo = `<p class="price">From ₹${lowestPriceINR.toLocaleString('en-IN')}</p>`;
        }
        // }

        card.innerHTML = `
            <img src="${imageUrl}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>${product.description ? product.description.substring(0, 60) + '...' : 'No description available.'}</p>
            <!-- Price placeholder removed --> 
            <a href="product-details.html?id=${product.id}" class="btn">View Details</a>
        `;
        featuredProductsGrid.appendChild(card);
    });
});
