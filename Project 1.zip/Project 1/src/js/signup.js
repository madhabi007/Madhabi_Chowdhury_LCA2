// DOM Elements
const signupForm = document.getElementById('signupForm');
const nameInput = document.getElementById('name');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const confirmPasswordInput = document.getElementById('confirm-password');
const togglePasswordButtons = document.querySelectorAll('.toggle-password');
const googleBtn = document.querySelector('.google-btn');
const facebookBtn = document.querySelector('.facebook-btn');
const loadingOverlay = document.querySelector('.loading-overlay');

// Function to show loading overlay
function showLoadingOverlay() {
    if (loadingOverlay) {
        loadingOverlay.classList.add('active');
    }
}

// Function to hide loading overlay
function hideLoadingOverlay() {
    if (loadingOverlay) {
        loadingOverlay.classList.remove('active');
    }
}

// Initialize page
window.addEventListener('DOMContentLoaded', () => {
    // Hide loading overlay after DOM is loaded
    hideLoadingOverlay();
});

// Event Listeners
signupForm.addEventListener('submit', handleSignup);
togglePasswordButtons.forEach(button => {
    button.addEventListener('click', () => togglePasswordVisibility(button));
});
googleBtn.addEventListener('click', handleGoogleSignup);
facebookBtn.addEventListener('click', handleFacebookSignup);

// Functions
function handleSignup(e) {
    e.preventDefault();
    
    const name = nameInput.value.trim();
    const email = emailInput.value.trim();
    const password = passwordInput.value;
    const confirmPassword = confirmPasswordInput.value;
    
    // Validate form
    if (!isValidName(name)) {
        showError(nameInput, 'Please enter a valid name');
        return;
    }
    
    if (!isValidEmail(email)) {
        showError(emailInput, 'Please enter a valid email address');
        return;
    }
    
    if (!isValidPassword(password)) {
        showError(passwordInput, 'Password must be at least 8 characters long');
        return;
    }
    
    if (password !== confirmPassword) {
        showError(confirmPasswordInput, 'Passwords do not match');
        return;
    }
    
    // Show loading state
    const submitBtn = signupForm.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating Account...';
    
    // Show loading overlay
    showLoadingOverlay();
    
    // Process signup immediately
    // Extract initials from full name
    const nameParts = name.split(' ').filter(part => part.trim() !== '');
    const initials = nameParts.map(part => part[0].toUpperCase()).join('');
    
    // Store user data in localStorage
    const userData = {
        name: name, // Store full name
        email: email,
        profilePicture: 'https://via.placeholder.com/150',
        orders: 0,
        points: 0,
        initials: initials // Store the initials
    };
    localStorage.setItem('user', JSON.stringify(userData));
    
    // Hide loading overlay
    hideLoadingOverlay();
    
    // Show success message
    showSuccess('Account created successfully! Redirecting to login...');
    
    // Redirect to login page after a short delay
    setTimeout(() => {
        window.location.href = 'login.html';
    }, 500);
}

function isValidName(name) {
    return name.length >= 2;
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function isValidPassword(password) {
    return password.length >= 8;
}

function togglePasswordVisibility(button) {
    const input = button.previousElementSibling;
    const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
    input.setAttribute('type', type);
    
    // Toggle eye icon
    const icon = button.querySelector('i');
    icon.classList.toggle('fa-eye');
    icon.classList.toggle('fa-eye-slash');
}

function showError(input, message) {
    const errorDiv = input.nextElementSibling;
    if (errorDiv) {
        errorDiv.textContent = message;
        errorDiv.style.display = 'block';
    }
    input.classList.add('error');
    
    // Clear error after 1 second
    setTimeout(() => {
        if (errorDiv) {
            errorDiv.style.display = 'none';
        }
        input.classList.remove('error');
    }, 1000);
}

function showSuccess(message) {
    const successDiv = document.createElement('div');
    successDiv.className = 'success-message';
    successDiv.textContent = message;
    signupForm.appendChild(successDiv);
    
    // Remove message after 1 second
    // Remove success message after 3 seconds
    setTimeout(() => {
        successDiv.remove();
    }, 3000);
}

function handleGoogleSignup() {
    // In a real application, you would implement Google OAuth here
    showSuccess('Redirecting to Google signup...');
}

function handleFacebookSignup() {
    // In a real application, you would implement Facebook OAuth here
    showSuccess('Redirecting to Facebook signup...');
}

// Add CSS for error and success messages
const style = document.createElement('style');
style.textContent = `
    .error-message, .success-message {
        padding: 0.5rem;
        margin: 0.5rem 0;
        border-radius: 4px;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        animation: fadeIn 0.3s ease;
    }
    
    .error-message {
        background-color: rgba(255, 0, 0, 0.1);
        color: #ff0000;
    }
    
    .success-message {
        background-color: rgba(0, 255, 0, 0.1);
        color: #00aa00;
    }
    
    .error {
        border-color: #ff0000 !important;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .fa-spinner {
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
`;
document.head.appendChild(style); 