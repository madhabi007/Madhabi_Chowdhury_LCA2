// DOM Elements
const loginForm = document.getElementById('loginForm');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const togglePasswordButton = document.querySelector('.toggle-password');
const googleBtn = document.querySelector('.google-btn');
const facebookBtn = document.querySelector('.facebook-btn');
const signupLink = document.querySelector('.signup-link a');
const errorDiv = document.getElementById('loginError');
const loadingOverlay = document.getElementById('loadingOverlay');

// Hide loading overlay after page load
window.addEventListener('load', () => {
    if (loadingOverlay) {
        loadingOverlay.classList.add('active');
        setTimeout(() => {
            loadingOverlay.classList.remove('active');
        }, 500);
    }
});

// Event Listeners
loginForm.addEventListener('submit', handleLogin);
togglePasswordButton.addEventListener('click', () => togglePasswordVisibility(togglePasswordButton));
googleBtn.addEventListener('click', handleGoogleLogin);
facebookBtn.addEventListener('click', handleFacebookLogin);
signupLink.addEventListener('click', (e) => {
    e.preventDefault();
    window.location.href = 'signup.html';
});

// Functions
function handleLogin(e) {
    e.preventDefault();
    
    const email = emailInput.value.trim();
    const password = passwordInput.value;
    
    // Validate form
    if (!isValidEmail(email)) {
        showError(emailInput, 'Please enter a valid email address');
        return;
    }
    
    if (!isValidPassword(password)) {
        showError(passwordInput, 'Password must be at least 8 characters long');
        return;
    }
    
    // Show loading state
    const submitBtn = loginForm.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Signing In...';
    
    // Get user data from localStorage (if exists)
    const userData = JSON.parse(localStorage.getItem('user')) || {
        name: email.split('@')[0], // Fallback to email name if no user data
        email: email,
        profilePicture: 'https://via.placeholder.com/150',
        orders: 0,
        points: 0
    };
    
    // Extract initials from name
    const nameParts = userData.name.split(' ').filter(part => part.trim() !== '');
    userData.initials = nameParts.map(part => part[0].toUpperCase()).join('');
    
    // Update user data with current email
    userData.email = email;
    localStorage.setItem('user', JSON.stringify(userData));
    
    // Show success message
    showSuccess('Login successful!');
    
    // Redirect to index.html
    window.location.href = 'index.html';
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function isValidPassword(password) {
    return password.length >= 8;
}

function togglePasswordVisibility(button) {
    const input = button.previousElementSibling;
    const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
    input.setAttribute('type', type);
    
    // Toggle eye icon
    const icon = button.querySelector('i');
    icon.classList.toggle('fa-eye');
    icon.classList.toggle('fa-eye-slash');
}

function showSuccess(message) {
    const successDiv = document.createElement('div');
    successDiv.className = 'success-message';
    successDiv.innerHTML = `<i class="fas fa-check-circle"></i> ${message}`;
    
    // Remove any existing success message
    const existingSuccess = document.querySelector('.success-message');
    if (existingSuccess) {
        existingSuccess.remove();
    }
    
    loginForm.insertBefore(successDiv, loginForm.firstChild);
    
    // Remove success message after 2 seconds
    setTimeout(() => {
        successDiv.remove();
        // Reset button
        const submitBtn = loginForm.querySelector('button[type="submit"]');
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Sign In';
    }, 1000);
}

function showError(input, message) {
    const formGroup = input.parentElement;
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${message}`;
    
    // Remove any existing error message
    const existingError = formGroup.querySelector('.error-message');
    if (existingError) {
        existingError.remove();
    }
    
    formGroup.appendChild(errorDiv);
    input.classList.add('error');
    
    // Remove error after 3 seconds
    setTimeout(() => {
        errorDiv.remove();
        input.classList.remove('error');
    }, 3000);
}

function handleGoogleLogin() {
    // In a real application, you would implement Google OAuth here
    showSuccess('Redirecting to Google login...');
}

function handleFacebookLogin() {
    // In a real application, you would implement Facebook OAuth here
    showSuccess('Redirecting to Facebook login...');
}

document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const errorDiv = document.getElementById('loginError');

    if (loginForm) {
        loginForm.addEventListener('submit', (event) => {
            // Prevent the actual form submission for now
            event.preventDefault(); 

            const emailValue = emailInput.value.trim();
            const passwordValue = passwordInput.value.trim();

            // Clear previous errors// Add keyboard navigation for form submission
            loginForm.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    handleLogin(e);
                }
            });
            errorDiv.textContent = ''; 
            emailInput.style.borderColor = ''; // Reset border color
            passwordInput.style.borderColor = ''; // Reset border color

            let isValid = true;
            let errorMessage = '';

            // Basic validation: Check if fields are empty
            if (emailValue === '') {
                errorMessage = 'Please enter your email.';
                emailInput.style.borderColor = 'red';
                isValid = false;
            } else if (passwordValue === '') { // Check password only if email is not empty
                errorMessage = 'Please enter your password.';
                passwordInput.style.borderColor = 'red';
                isValid = false;
            }

            if (!isValid) {
                errorDiv.textContent = errorMessage;
            } else {
                // If validation passes (both fields filled)
                // In a real application, you would send data to the server here.
                console.log('Login form submitted (validation passed).');
                // Optionally, disable the button to prevent multiple submits
                loginForm.querySelector('button[type="submit"]').disabled = true;
                loginForm.querySelector('button[type="submit"]').textContent = 'Signing In...';
                
                // Simulate a network request for demonstration
                setTimeout(() => {
                    // Replace with actual login logic later
                    alert('Login successful!'); 
                    // Redirect or update UI after successful login
                     loginForm.querySelector('button[type="submit"]').disabled = false;
                     loginForm.querySelector('button[type="submit"]').innerHTML = '<i class="fas fa-sign-in-alt"></i> Sign In'; // Restore button text
                    // window.location.href = '/dashboard.html'; // Example redirect
                }, 1500); // Simulate 1.5 second delay
            }
        });
    }

    // Optional: Toggle password visibility
    const togglePasswordButton = document.querySelector('.toggle-password');
    if (togglePasswordButton && passwordInput) {
        togglePasswordButton.addEventListener('click', () => {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            // Toggle eye icon
            togglePasswordButton.querySelector('i').classList.toggle('fa-eye');
            togglePasswordButton.querySelector('i').classList.toggle('fa-eye-slash');
        });
    }
});

// Add CSS for error and success messages
const style = document.createElement('style');
style.textContent = `
    .error-message, .success-message {
        padding: 0.5rem;
        margin: 0.5rem 0;
        border-radius: 4px;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        animation: fadeIn 0.3s ease;
    }
    
    .error-message {
        background-color: rgba(255, 0, 0, 0.1);
        color: #ff0000;
    }
    
    .success-message {
        background-color: rgba(0, 255, 0, 0.1);
        color: #00aa00;
    }
    
    .error {
        border-color: #ff0000 !important;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .fa-spinner {
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
`;
document.head.appendChild(style);

// Add dark mode toggle functionality
const darkModeToggle = document.createElement('button');
darkModeToggle.className = 'dark-mode-toggle';
darkModeToggle.innerHTML = '<i class="fas fa-moon"></i>';
document.body.appendChild(darkModeToggle);

darkModeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    const icon = darkModeToggle.querySelector('i');
    icon.classList.toggle('fa-moon');
    icon.classList.toggle('fa-sun');
}); 