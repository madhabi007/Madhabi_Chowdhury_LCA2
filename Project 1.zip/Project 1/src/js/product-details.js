// Mock data (copied from search.js - temporary solution until backend)
const sampleProducts = [
    {
        id: 1,
        name: "Samsung Galaxy S23 Ultra",
        image: "https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcRCjyekLTGxFsl4qRLxSG1Z-mqNJWIzPgRkGKmbrbqdmOmpH6D2Rh8z-rRBfO2o1wfXa-uRmj_LDp0YsbFNCB6kCLfvZ3ts",
        category: "electronics",
        description: "High-end smartphone with advanced camera.",
        prices: [
            { platform: "Amazon", price: 1199.99, url: "https://www.amazon.com/s?k=samsung+galaxy+s23+ultra", rating: 4.8, reviews: 5213 },
            { platform: "Flipkart", price: 1189.99, url: "https://www.flipkart.com/search?q=samsung+galaxy+s23+ultra", rating: 4.7, reviews: 4890 },
            { platform: "Best Buy", price: 1219.99, url: "https://www.bestbuy.com/site/samsung-galaxy-s23-ultra-5g-unlocked-smartphone/6599103.p?skuId=6599103", rating: 4.8, reviews: 5100 }
        ]
    },
    {
        id: 2,
        name: "MacBook Air M2",
        image: "https://store.storeimages.cdn-apple.com/1/as-images.apple.com/is/mba13-silver-cto-hero-202503?wid=840&hei=498&fmt=jpeg&qlt=90&.v=U0Z6SXlYc1BFM1JiK2VsbitpZmJQbTlvelV1clpMQ1I3STRPWXROdW1jM3c5YVIwb1U2bDJuTk1wdkVlT3RmUk14MXJScFRZN3Y5OWZsRXVrN1k4cGRRc1UweFFQYjRpK3pPQllDSFNnc0U",
        category: "electronics",
        description: "Apple's lightweight laptop with M2 chip.",
        prices: [
            { platform: "Amazon", price: 1299.00, url: "https://www.amazon.com/s?k=macbook+air+m2", rating: 4.9, reviews: 3456 },
            { platform: "Best Buy", price: 1319.00, url: "https://www.bestbuy.com/site/apple-macbook-air-m2-13-6-inch-laptop/6599103.p?skuId=6599103", rating: 4.9, reviews: 3300 }
        ]
    },
    {
        id: 3,
        name: "Sony WH-1000XM5",
        image: "https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcQ0R9BC93mX2BHmhNoJjGi-IJ4DXM6-uIE9he2GD2saKZ_ogUMAqPksTtnT-oXSMtTsKplSmYuh6dL0q0n83fKOybZx5eg4bw",
        category: "electronics",
        description: "Industry-leading noise-canceling headphones.",
        prices: [
            { platform: "Amazon", price: 399.99, url: "https://www.amazon.com/s?k=sony+wh-1000xm5", rating: 4.7, reviews: 2123 },
            { platform: "Flipkart", price: 389.99, url: "https://www.flipkart.com/search?q=sony+wh-1000xm5", rating: 4.6, reviews: 1980 },
        ]
    },
    {
        id: 4,
        name: "Nike Air Max 270 ",
        image: "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcQSuVPbLK3ck3C5zf0DWrLps_Ao3-2GGNxsyvpHvrrqJ1shLf3zV6rbYBc8ZnlwHEzuQ_fkIWnDyuvQoKnGlRLLkr57AdQKY-t_oM3ltshOgwSuBDQydT1q1w",
        category: "fashion",
        description: "Comfortable lifestyle sneakers.",
        prices: [
            { platform: "Amazon", price: 149.99, url: "https://www.amazon.com/s?k=nike+air+max+270", rating: 4.6, reviews: 1530 },
            { platform: "Flipkart", price: 139.99, url: "https://www.flipkart.com/search?q=nike+air+max+270", rating: 4.5, reviews: 1400 }
        ]
    },
    {
        id: 5,
        name: "Levi's 501 Jeans",
        image: "https://assets.ajio.com/medias/sys_master/root/hd3/hf3/9262962343966/-473Wx593H-460027749-blue-MODEL6.jpg",
        category: "fashion",
        description: "Classic straight fit denim jeans.",
        prices: [
            { platform: "Amazon", price: 89.99, url: "#amazon-levis", rating: 4.4, reviews: 2800 },
            { platform: "Best Buy", price: 95.99, url: "#bestbuy-levis", rating: 4.5, reviews: 2650 }
        ]
    },
     {
        id: 6,
        name: "Philips Hue Smart Bulb",
        image: "https://cdn.shopify.com/s/files/1/0648/5478/6148/files/Image1.jpg?v=1722580287",
        category: "home",
        description: "Color ambiance smart light bulb.",
        prices: [
            { platform: "Amazon", price: 49.99, url: "#amazon-hue", rating: 4.7, reviews: 9800 },
            { platform: "Best Buy", price: 52.99, url: "#bestbuy-hue", rating: 4.7, reviews: 9500 }
        ]
    },
    {
        id: 7,
        name: "Instant Pot Duo",
        image: "https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcQCXuNp469RBPjnO1Mu7mP2ceIL0zPR5ZNS6f91m2eujg-Tv5ssT3Laslj3oGMF5zbPZsMnQjqJQJvkYkJgZTUg_tiWnEAyRzWlXhNsuWbc4bMRU0snm1uNDw",
        category: "home",
        description: "7-in-1 electric pressure cooker.",
        prices: [
            { platform: "Amazon", price: 89.99, url: "#amazon-ipot", rating: 4.8, reviews: 15000 },
            { platform: "Flipkart", price: 85.99, url: "#flipkart-ipot", rating: 4.7, reviews: 14200 }
        ]
    },
    {
        id: 8,
        name: "Atomic Habits",
        image: "https://m.media-amazon.com/images/I/61Bhf8CdaML._SY466_.jpg",
        category: "books",
        description: "An Easy & Proven Way to Build Good Habits & Break Bad Ones.",
        prices: [
            { platform: "Amazon", price: 14.99, url: "#amazon-ah", rating: 4.9, reviews: 55000 },
            { platform: "Flipkart", price: 13.99, url: "#flipkart-ah", rating: 4.8, reviews: 52100 }
        ]
    },
     {
        id: 9,
        name: "Fitbit Charge 5",
        image: "https://m.media-amazon.com/images/I/61Llpu4OGYL._SX679_PIbundle-4,TopRight,0,0_AA679SH20_.jpg",
        category: "sports",
        description: "Advanced fitness & health tracker.",
        prices: [
            { platform: "Amazon", price: 149.95, url: "#amazon-fitbit", rating: 4.4, reviews: 12000 },
            { platform: "Best Buy", price: 149.99, url: "#bestbuy-fitbit", rating: 4.4, reviews: 11500 }
        ]
    }
];

document.addEventListener('DOMContentLoaded', () => {

    // Get URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const productIdParam = urlParams.get('id');
    const productId = productIdParam ? parseInt(productIdParam) : null;

    if (productId === null || isNaN(productId)) {
        displayError("Invalid Product ID");
        return;
    }

    // Find the product from the sample data
    const product = sampleProducts.find(p => p.id === productId);

    if (!product) {
        displayError("Product Not Found", "Sorry, the product you're looking for doesn't exist or the ID is incorrect.");
        return;
    }

    // --- DOM Element Selection --- (Ensure these IDs exist in product-details.html)
    const mainImage = document.getElementById('main-product-image');
    const productName = document.getElementById('product-name');
    const bestPrice = document.getElementById('best-price');
    const bestPlatform = document.getElementById('best-platform');
    const productRating = document.getElementById('product-rating');
    const reviewCount = document.getElementById('review-count');
    const platformComparison = document.getElementById('platform-comparison');
    const buyButtons = document.getElementById('buy-buttons');
    const productSpecs = document.getElementById('product-specs'); // Assuming this ID exists
    const thumbnailContainer = document.querySelector('.thumbnail-images'); // Assuming this class exists
    const productCategory = document.getElementById('product-category'); // Assuming this ID exists
    const productFeatures = document.getElementById('product-features'); // Assuming this ID exists

    // --- Check if elements exist before manipulating --- 
    if (!mainImage || !productName || !bestPrice || !bestPlatform || !productRating || !reviewCount || !platformComparison || !buyButtons || !productSpecs || !thumbnailContainer || !productCategory || !productFeatures) {
        console.error("One or more essential product detail elements are missing from the HTML.");
        displayError("Page Structure Error", "Could not display product details correctly.");
        return;
    }

    // --- Populate Page --- 
    // Use local placeholder if product.image is missing or invalid
    const imageUrl = product.image && product.image.trim() !== '' ? product.image : 'images/placeholder-category.png';
    mainImage.src = imageUrl;
    mainImage.alt = product.name;
    productName.textContent = product.name;
    productCategory.textContent = product.category;

    // Find the best price and platform
    const bestPriceInfo = findBestPrice(product.prices);

    if (bestPriceInfo) {
        bestPrice.textContent = `₹${Math.round(bestPriceInfo.price * 83).toLocaleString('en-IN')}`;
        bestPlatform.textContent = `on ${bestPriceInfo.platform}`;
    } else {
        bestPrice.textContent = "N/A";
        bestPlatform.textContent = "";
    }

    // Set rating and reviews (Using mock rating/reviews for now)
    const averageRating = calculateAverageRating(product.prices);
    const totalReviews = sumReviews(product.prices);
    productRating.innerHTML = generateStarRating(averageRating); 
    reviewCount.textContent = `(${totalReviews.toLocaleString()} reviews)`;

    // Create platform comparison cards
    platformComparison.innerHTML = ''; // Clear existing
    product.prices.forEach(price => {
        const platformCard = document.createElement('div');
        platformCard.className = 'platform-card'; 
        // Basic icon mapping - needs improvement for real logos
        let platformIcon = 'fa-store'; 
        if (price.platform.toLowerCase() === 'amazon') platformIcon = 'fa-amazon';
        if (price.platform.toLowerCase() === 'flipkart') platformIcon = 'fa-shopping-bag'; // Example, adjust as needed
        if (price.platform.toLowerCase() === 'best buy') platformIcon = 'fa-laptop'; // Example, adjust as needed

        platformCard.innerHTML = `
            <div class="platform-logo">
                <i class="fab ${platformIcon}"></i> 
            </div>
            <div class="platform-info">
                <h3>${price.platform}</h3>
                <p class="platform-price">₹${Math.round(price.price * 83).toLocaleString('en-IN')}</p>
                ${bestPriceInfo && price.price === bestPriceInfo.price ? 
                    '<span class="best-price-tag">Best Price</span>' : ''}
            </div>
            <a href="${price.url}" target="_blank" class="btn-platform-link">View Deal <i class="fas fa-external-link-alt"></i></a>
        `;
        platformComparison.appendChild(platformCard);
    });

    // Create buy buttons (Simplified for this example)
    buyButtons.innerHTML = ''; // Clear existing
    if (bestPriceInfo) {
        const buyButton = document.createElement('a');
        buyButton.className = 'buy-button primary'; // Add primary class
        buyButton.href = bestPriceInfo.url;
        buyButton.target = '_blank';
        buyButton.innerHTML = `
            Buy Best Deal Now - ₹${Math.round(bestPriceInfo.price * 83).toLocaleString('en-IN')}
        `;
        buyButtons.appendChild(buyButton);
    }

    // Create product specifications (Using mock specs)
    productSpecs.innerHTML = ''; // Clear existing
    const specs = {
        'Category': product.category,
        'Description': product.description,
        'Best Price': bestPriceInfo ? `₹${Math.round(bestPriceInfo.price * 83).toLocaleString('en-IN')} on ${bestPriceInfo.platform}` : 'N/A',
        'Platforms Checked': product.prices.map(p => p.platform).join(', '),
        'Average Rating': `${averageRating.toFixed(1)} stars`
    };
    Object.entries(specs).forEach(([label, value]) => {
        const specItem = document.createElement('div');
        specItem.className = 'spec-item';
        specItem.innerHTML = `
            <span class="spec-label">${label}:</span>
            <span class="spec-value">${value}</span>
        `;
        productSpecs.appendChild(specItem);
    });

    // Populate features (Using description for now)
    productFeatures.innerHTML = `<li>${product.description}</li>`; // Simple example

    // Add thumbnail images (Using main image multiple times as placeholder)
    thumbnailContainer.innerHTML = ''; // Clear existing
    const imageUrls = [product.image, product.image, product.image]; // Placeholder for multiple images
    imageUrls.forEach((imgUrl, index) => {
        const thumbDiv = document.createElement('div');
        thumbDiv.className = 'thumbnail-image' + (index === 0 ? ' active' : '');
        thumbDiv.innerHTML = `<img src="${imgUrl}" alt="Product view ${index + 1}">`;
        thumbDiv.addEventListener('click', () => {
            // Remove active class from all thumbnails
            thumbnailContainer.querySelectorAll('.thumbnail-image').forEach(t => t.classList.remove('active'));
            // Add active class to the clicked one
            thumbDiv.classList.add('active');
            // Update the main image
            mainImage.src = imgUrl;
        });
        thumbnailContainer.appendChild(thumbDiv);
    });

}); // End of DOMContentLoaded

// --- Helper Functions ---

function displayError(title, message = "An unexpected error occurred.") {
    const body = document.querySelector('body');
    if (body) {
        body.innerHTML = `
            <div class="error-container" style="text-align: center; padding: 50px; font-family: sans-serif;">
                <h1>${title}</h1>
                <p>${message}</p>
                <a href="search.html" style="display: inline-block; margin-top: 20px; padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;">Back to Search</a>
            </div>
        `;
    }
}

function findBestPrice(prices) {
    if (!prices || prices.length === 0) return null;
    return prices.reduce((best, current) => {
        if (!best || current.price < best.price) {
            return current;
        }
        return best;
    }, null);
}

function calculateAverageRating(prices) {
    if (!prices || prices.length === 0) return 0;
    let totalRating = 0;
    let numRatings = 0;
    prices.forEach(p => {
        if (p.rating) {
            totalRating += p.rating;
            numRatings++;
        }
    });
    return numRatings > 0 ? totalRating / numRatings : 0;
}

function sumReviews(prices) {
     if (!prices || prices.length === 0) return 0;
     return prices.reduce((sum, p) => sum + (p.reviews || 0), 0);
}

function generateStarRating(rating) {
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 >= 0.5;
    const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);
    let starsHTML = '';
    for (let i = 0; i < fullStars; i++) starsHTML += '<i class="fas fa-star active"></i>';
    if (halfStar) starsHTML += '<i class="fas fa-star-half-alt active"></i>';
    for (let i = 0; i < emptyStars; i++) starsHTML += '<i class="far fa-star"></i>'; // Use far for empty stars
    return starsHTML;
}
