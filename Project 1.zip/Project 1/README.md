# PriceCompare - Smart Shopping Companion

PriceCompare is a modern, responsive web application that helps users find the best prices for products across multiple shopping platforms. The application features a sleek, luxury design with dark mode support and smooth animations.

TagTally is a web application designed to help users compare prices for products across various online retailers.

## Features

- **Price Comparison**: Compare prices of the same product across multiple shopping websites
- **Smart Search**: Find products quickly with auto-suggestions and filters
- **Best Price Guarantee**: Automatically identify and highlight the best deals
- **User Accounts**: Save searches, set price alerts, and manage preferences
- **Dark Mode**: Toggle between light and dark themes for comfortable browsing
- **Responsive Design**: Works seamlessly on all devices
- **Social Login**: Quick access through Google and Facebook accounts
*   Product Search
*   Price Comparison from multiple sources
*   User Accounts (Login/Sign Up - Planned)
*   Featured Products
*   Product Categories

## Pages

1. **Landing Page**
   - Eye-catching hero section
   - Feature highlights
   - Clear call-to-action

2. **Search Page**
   - Advanced search functionality
   - Platform and price filters
   - Product comparison cards

3. **Login/Signup**
   - Secure authentication
   - Social login options
   - Form validation

4. **User Dashboard**
   - Saved searches
   - Price alerts
   - Account settings

## Technologies Used

- HTML5
- CSS3 (with CSS Variables and Flexbox/Grid)
- JavaScript (ES6+)
- Font Awesome Icons
- Google Fonts

## Tech Stack

*   **Frontend:** HTML, CSS, JavaScript
*   **Backend:** Node.js, Express (Planned)

## Getting Started

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/pricecompare.git
   ```

2. Open the project directory:
   ```bash
   cd pricecompare
   ```

3. Open `index.html` in your web browser to view the application.

## Setup (Frontend)

1.  Clone the repository.
2.  Open the HTML files directly in your browser or use a live server extension.

## Setup (Backend - Planned)

1.  Navigate to the `backend` directory: `cd backend`
2.  Install dependencies: `npm install`
3.  Start the server: `npm start` (or `node server.js`)

## Project Structure

```
pricecompare/
├── index.html              # Landing page
├── search.html             # Search results page
├── login.html              # Login page
├── signup.html             # Signup page
├── src/
│   ├── css/
│   │   ├── styles.css      # Main styles
│   │   ├── search.css      # Search page styles
│   │   └── login.css       # Login page styles
│   └── js/
│       ├── main.js         # Main JavaScript
│       ├── search.js       # Search functionality
│       └── login.js        # Login functionality
└── images/                 # Image assets
```

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Font Awesome for the icons
- Google Fonts for the typography
- All contributors who have helped shape this project 